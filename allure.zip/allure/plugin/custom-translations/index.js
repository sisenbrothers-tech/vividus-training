'use strict';
allure.api.addTranslation('en', {"tab":{"suites":{"name":"Batches"},"custom-tab":{"name":"Custom tab"}},"widget":{"suites":{"name":"Batches"}}});
