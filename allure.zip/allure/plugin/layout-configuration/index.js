'use strict';
allure.api.tabs = allure.api.tabs.filter(t => !['custom-tab'].includes(t.tabName));
